﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SaMo.ViewModels
{
    public class DangKy
    {
        public DateTime NgayTao { get; set; }
        public List<DetailDk> NoiDung { get; set; }
    }
}